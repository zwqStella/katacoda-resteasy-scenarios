Your first JAX_RS Client and Server
========================
This project is a simple example showing usage of @Path, @GET, PUT, POST, and @PathParam.  It uses pure streaming
output as well. 

System Requirements:
-------------------------
- Maven 3.0.4 or higher

Building the project:
-------------------------
1. In root directory

mvn clean install

This will build a WAR and run it with embedded Jetty